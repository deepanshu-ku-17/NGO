// src/components/Navbar/Navbar.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

function Navbar() {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    return (
    <nav className="navbar">
        <Link to="/" className="logo">
        <img src="/images/logo only.png" alt="BlockAid" />
        </Link>
        <div className="menu-icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            <div className={`menu-line ${isMenuOpen ? 'open' : ''}`}></div>
        </div>
        <div className={`nav-links ${isMenuOpen ? 'active' : ''}`}>
            <Link to="/team">Team</Link>
            <Link to="/transparency">Transparency</Link>
            <Link to="/transaction">Transaction</Link>
            <Link to="/contact">Contact Us</Link>
            <Link to="/signup" className="signup-btn">Sign up →</Link>
        </div>
    </nav>
    );
}

export default Navbar;
