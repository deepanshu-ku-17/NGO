// src/pages/Home/Home.jsx
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './Home.css';
function Home() {
    const [isVisible, setIsVisible] = useState(false);
    useEffect(() => {
    setIsVisible(true);
}, []);
    return (
    <div className="home">
        <div className="content">
            <span className="tag">#BlockchainForGood</span>
            <h1>Revolutionize Charitable Giving with Blockchain</h1>
            <p>
                Transform your charitable giving using the ideal method - 
                the technology of the blockchain which is efficient, secure
                and highly transparent. BlockAid provides a platform to its 
                users where donations and NGOs are safe and verified.
            </p>
            <button className="start-btn">Start Now →</button>
        </div>
        <div className="image-section">
            <img 
            src="/donation-image.png" 
            alt="Donation Illustration"
            />
        </div>
    </div>
    )
}

export default Home
