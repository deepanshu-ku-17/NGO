// src/pages/Transparency/Transparency.jsx
import React from 'react'
import './Transparency.css'

function Transparency() {
    return (
    <div className="transparency-container">
        <h1>TRANSPARENCY</h1>
        <p className="description">
            We're working with several credible organizations and initiatives to ensure impactful 
            disbursement. Please refer to our open accounts below
        </p>
        <div className="legal-section">
            <h2>Legal and Financial</h2>
            <p>PwC Due Diligence report of Crypto Relief</p>
            <div className="documents">
                <div className="document">
                    <div className="doc-icon"></div>
                    <button>View</button>
                </div>
                <div className="document">
                    <div className="doc-icon"></div>
                    <button>View</button>
                </div>
                <div className="document">
                    <div className="doc-icon"></div>
                    <button>View</button>
                </div>
            </div>
        </div>
    </div>
    )
}

export default Transparency
