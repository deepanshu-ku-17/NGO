// src/pages/Team/Team.jsx
import React from 'react'
import './Team.css'


function Team() {
    return (
    <div className="team-container">
        <h1>TEAM</h1>
        <p className="team-description">
            Our Community consists of Founders and 
            Innovators, People Who Care For 
            The People of Our Country.
        </p>
        <div className="team-members">
            <div className="member-card">
                <img src="/team/deepanshu.jpg" alt="Team Member" />
                <h3>DEEPANSHU KUMAR</h3>
            </div>
            <div className="member-card">
                <img src="/team/himanshu.jpg" alt="Team Member" />
                <h3>HIMANSHU VASHISTHA</h3>
            </div>
            <div className="member-card">
                <img src="/team/sharad.jpg" alt="Team Member" />
                <h3>SHARAD SINGHAL</h3>
            </div>
        </div>
    </div>
    )
}

export default Team
