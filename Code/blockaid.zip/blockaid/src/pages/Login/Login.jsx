// src/pages/Login/Login.jsx
import React from 'react'
import './Login.css'


function Login() {
    return (
    <div className="login-container">
        <div className="login-box">
            <div className="logo-section">
                <h2>LOGIN</h2>
            </div>
            <div className="form-section">
                <button className="google-btn">
                    <img src="/google-icon.png" alt="Google" />
                    Continue with Google
                </button>
                <div className="divider">
                    <span>OR</span>
                </div>
                <form>
                    <div className="input-group">
                        <input 
                        type="text" 
                        placeholder="Username / Email"
                        />
                    </div>
                    <div className="input-group">
                        <input 
                        type="password" 
                        placeholder="Password"
                        />
                        <span className="eye-icon">👁️</span>
                    </div>
                    <div className="form-options">
                        <label>
                            <input type="checkbox" /> Remember me
                        </label>
                        <a href="#forgot">Forgot Password</a>
                    </div>
                    <button type="submit" className="login-btn">
                        LOGIN →
                    </button>
                    <p className="signup-link">
                        Don't have an account? 
                        <a href="#signup">Sign up</a>
                    </p>
                </form>
            </div>
        </div>
    </div>
    )
}

export default Login
