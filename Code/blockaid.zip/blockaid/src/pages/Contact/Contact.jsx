// src/pages/Contact/Contact.jsx
import React from 'react'
import './Contact.css'
<img src="/logo.png" alt="BlockAid Logo" />

function Contact() {
    return (
    <div className="contact-container">
        <h2>CONTACT</h2>
        <div className="contact-content">
            <div className="contact-image">
                <img 
                    src="/email-image.png" 
                    alt="Contact"
                />
                <div className="social-links">
                    <a href="#email"><span>✉️</span></a>
                    <a href="#phone"><span>📞</span></a>
                    <a href="#twitter"><span>🐦</span></a>
                    <a href="#photo"><span>📷</span></a>
                </div>
            </div>
            <form className="contact-form">
                <div className="input-group">
                    <input type="text" placeholder="NAME" />
                </div>
                <div className="input-group">
                    <input type="email" placeholder="EMAIL" />
                </div>
                <div className="input-group">
                    <input type="text" placeholder="OBJECTIVE" />
                </div>
                <div className="input-group">
                    <textarea placeholder="MESSAGE"></textarea>
                </div>
                <button type="submit" className="submit-btn">
                    Submit →
                </button>
            </form>
        </div>
    </div>
    )
}

export default Contact
