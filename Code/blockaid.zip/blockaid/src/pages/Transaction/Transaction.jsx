// src/pages/Transaction/Transaction.jsx
import React from 'react'
import './Transaction.css'

function Transaction() {
    return (
    <div className="transaction-container">
        <h1>DONATE</h1>
        <p className="description">
            We are using a Gnosis Multi-Signature Wallet to handle the donations, 
            in a transparent way.
        </p>
        <div className="wallet-addresses">
            <div className="wallet-row">
                <div className="coin">BTC</div>
                <div className="address">XXXXX#X##x#X</div>
            </div>
            <div className="wallet-row">
                <div className="coin">DOGECOIN</div>
                <div className="address">XXXXX#X##x#X</div>
            </div>
            <div className="wallet-row">
                <div className="coin">ETH</div>
                <div className="address">XXXXX#X##x#X</div>
            </div>
            <div className="wallet-row">
                <div className="coin">LITECOIN</div>
                <div className="address">XXXXX#X##x#X</div>
            </div>
        </div>
    </div>
    )
}

export default Transaction
