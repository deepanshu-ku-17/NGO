// src/pages/Signup/Signup.jsx
import React from 'react'
import './Signup.css'


function Signup() {
    return (
    <div className="signup-container">
        <div className="signup-box">
            <div className="logo-section">
                <h2>SIGNUP</h2>
            </div>
            <div className="form-section">
                <button className="google-btn">
                    <img src="/google-icon.png" alt="Google" />
                    Continue with Google
                </button>
                <div className="divider">
                    <span>OR</span>
                </div>
                <form>
                    <div className="name-group">
                        <input type="text" placeholder="First Name" />
                        <input type="text" placeholder="Last Name" />
                    </div>
                    <div className="input-group">
                        <input type="text" placeholder="Username / Email" />
                    </div>
                    <div className="input-group">
                        <input type="password" placeholder="Password" />
                        <span className="eye-icon">👁️</span>
                    </div>
                    <button type="submit" className="signup-button">
                        Register →
                    </button>
                    <p className="login-link">
                        Already have an account? 
                        <a href="#login">Login</a>
                    </p>
                </form>
            </div>
        </div>
    </div>
    )
}

export default Signup
